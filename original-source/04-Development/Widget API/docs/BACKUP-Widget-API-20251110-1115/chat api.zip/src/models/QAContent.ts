export interface QAContent {
  question: string;
  answer: string;
}
